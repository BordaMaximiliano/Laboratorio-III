
var cantidadsumas = 0;

//Se declara la funcion onblur de la caja de texto.
//El dom se carga despues de la ejecucion de la pagina. 
//es por ello que debemos de colocar dentro del metodo Onload() para que se ejecute luego de que este cargada la pagina.
window.onload =
    function () {
        $("valor1").onblur =
        function () {
            if ($("valor1").value == "") {
                mostrarMsj("debe de seleccionar un numero 1");
                $("valor1").focus();
            }
        }

        $("valor2").onblur =
        function () {
            if ($("valor2").value == "") {
                mostrarMsj("debe de seleccionar un numero 2");
                $("valor2").focus();
            }
        }


    }

//funcion para no escribir get elemnt 
//retorna al objeto don que le pasamos.
function $(elementoId) {
    return document.getElementById(elementoId);
}


function clickme(mensaje) {
    alert(mensaje);
}

function mostrarMsj(msj) {
    document.getElementById("mensaje").innerHTML = msj ;
}

function agregarHistoricoRustico(valor1, valor2, resultado) {
    var registro = "<tr><th>" + cantidadsumas++ + "</th><td>" + valor1 + "</td><td>" + valor2 + "</td><td> " + resultado + "</td></tr>";
    document.getElementById("tHistBody").innerHTML = document.getElementById("tHistBody").innerHTML + registro;
}

//Funcion de creacion de fila nueva de la tabla.
function agregarHistorico(valor1, valor2, resultado) {

    var tabla = $("tHistBody");

    var row = tabla.insertRow(0);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);

    cell1.innerHTML = cantidadsumas;
    cell2.innerHTML = valor1;
    cell3.innerHTML = valor2;
    cell4.innerHTML = resultado;
    
}

function calcular(valor1, valor2) {

    try {       

        var resultado;
        var valortext1 = document.getElementById(valor1).value;
        var valortext2 = document.getElementById(valor2).value;

        if (!valortext1 == '' && !valortext1 == '') {
            //El caracter + concatena. ya que las variables no son tipadas.
            //Para que no concatene hay que castear con float o parseint
            resultado = parseFloat(valortext1) + parseFloat(valortext2);

            //Con el console guardo logueo por consola de desarrollo f12
            console.log("El resultado fue: " + resultado);

        } else {
            resultado = "Debe de colocar dos valores numericos";
        }

        alert(resultado);

        agregarHistorico(valortext1, valortext2, resultado);
        

    }
    catch (err) {

        //Con el console guardo logueo por consola de desarrollo f12
        console.log("hubo un error critico" + err.toString());
        alert("Error critico");

    }

    
    
}